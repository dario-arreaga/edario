export default function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/593991680747"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-5 right-5 md:bottom-6 md:right-6 z-30 inline-flex items-center justify-center rounded-full px-4 py-3 shadow-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold gap-2"
    >
      <span>WhatsApp</span>
      <span className="text-lg">💬</span>
    </a>
  );
}
