export default function ServiceCard({ title, description, items }) {
  return (
    <div className="card h-full flex flex-col">
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-slate-300 mb-3">{description}</p>
      {items && (
        <ul className="text-sm text-slate-300 space-y-1 mb-4">
          {items.map((item) => (
            <li key={item}>• {item}</li>
          ))}
        </ul>
      )}
      <div className="mt-auto">
        <p className="text-xs text-slate-500">
          Consulta sin compromiso al <span className="font-semibold">0991680747</span>
        </p>
      </div>
    </div>
  );
}
