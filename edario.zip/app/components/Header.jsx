import Link from "next/link";

export default function Header() {
  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur sticky top-0 z-20">
      <div className="container-base flex items-center justify-between py-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-xl bg-brand flex items-center justify-center text-xl font-black">
            ED
          </div>
          <div>
            <p className="font-semibold text-sm md:text-base">
              Electrónica Darío
            </p>
            <p className="text-xs text-slate-400">
              Servicio técnico en electrónica
            </p>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm">
          <Link href="/" className="hover:text-brand transition">
            Inicio
          </Link>
          <Link href="/servicios" className="hover:text-brand transition">
            Servicios
          </Link>
          <Link href="/sobre-mi" className="hover:text-brand transition">
            Sobre mí
          </Link>
          <Link href="/contacto" className="hover:text-brand transition">
            Contacto
          </Link>
        </nav>

        <a
          href="https://wa.me/593991680747"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden md:inline-flex btn-primary text-xs"
        >
          WhatsApp
        </a>
      </div>
    </header>
  );
}
