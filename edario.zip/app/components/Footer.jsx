export default function Footer() {
  return (
    <footer className="border-t border-slate-800 mt-12">
      <div className="container-base py-8 text-sm text-slate-400 flex flex-col md:flex-row items-center justify-between gap-3">
        <p>© {new Date().getFullYear()} Electrónica Darío. Todos los derechos reservados.</p>
        <p className="text-xs">
          Reparación de electrodomésticos · Computadoras · Laptops · Impresoras ·
          Licencias Windows / Office
        </p>
      </div>
    </footer>
  );
}
