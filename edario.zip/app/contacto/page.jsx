import Header from "../../components/Header";
import Footer from "../../components/Footer";
import WhatsAppButton from "../../components/WhatsAppButton";

export const metadata = {
  title: "Contacto | Electrónica Darío",
};

export default function ContactoPage() {
  return (
    <>
      <Header />
      <main className="section">
        <div className="container-base max-w-2xl">
          <h1 className="text-2xl md:text-3xl font-semibold mb-4">
            Contacto
          </h1>
          <p className="text-sm md:text-base text-slate-300 mb-4">
            Puedes contactarme por llamada o WhatsApp para consultas, cotizaciones
            y agendar visitas a domicilio.
          </p>

          <div className="card space-y-4">
            <div>
              <h2 className="text-sm font-semibold mb-1">Teléfono / WhatsApp</h2>
              <p className="text-sm text-slate-200">
                <a href="tel:+593991680747" className="hover:text-brand">
                  0991680747
                </a>
              </p>
            </div>

            <div>
              <h2 className="text-sm font-semibold mb-1">WhatsApp directo</h2>
              <a
                href="https://wa.me/593991680747"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex justify-center"
              >
                Abrir chat de WhatsApp
              </a>
            </div>

            <div>
              <h2 className="text-sm font-semibold mb-1">Horario de atención</h2>
              <p className="text-sm text-slate-300">
                Lunes a sábado · 9:00 a 18:00
              </p>
            </div>

            <p className="text-xs text-slate-500">
              Si no contesto de inmediato, probablemente estoy en reparación o en
              ruta a domicilio. Déjame tu mensaje y te respondo lo antes posible.
            </p>
          </div>
        </div>
      </main>
      <WhatsAppButton />
      <Footer />
    </>
  );
}
